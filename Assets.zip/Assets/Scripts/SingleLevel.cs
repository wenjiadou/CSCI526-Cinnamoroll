using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SingleLevel : MonoBehaviour
{
    //public GameObject[] popUps;
    //private int popUpIndex;

    private int currentStarsNum = 0;
    public int levelIndex;
    private GameObject player;
    private HeartSystem heartSystem;
    private PlayerController playerController;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        heartSystem = player.GetComponent<HeartSystem>();
        playerController = player.GetComponent<PlayerController>();
    }

    void Update()
    {
        StarRecord();
    }

    public void BackButton()
    {
        SceneManager.LoadScene("Level Selection");
    }

   //public void PressStarsButton(int _starsNum)
   // {
   //     currentStarsNum = _starsNum;

   //     if (currentStarsNum > PlayerPrefs.GetInt("Lv" + levelIndex))
   //     {
   //         PlayerPrefs.SetInt("Lv" + levelIndex, _starsNum);
   //     }

   //     //BackButton();
   //     //MARKER Each level has saved their own stars number
   //     //CORE PLayerPrefs.getInt("KEY", "VALUE"); We can use the KEY to find Our VALUE
   //     Debug.Log(PlayerPrefs.GetInt("Lv" + levelIndex, _starsNum));

   //     // BackButton();
   // }

    public void StarRecord()
    {
        // Player get the destination
        if (playerController.playVictoryAnimation)
        {
            if (heartSystem.life == 1)
            {
                currentStarsNum = 1;
                // popUpIndex = 6;  //1 star pass
            }
            else if (heartSystem.life == 2)
            {
                currentStarsNum = 2;
                // popUpIndex = 7;  //2 star pass
            }
            else if (heartSystem.life == 3)
            {
                currentStarsNum = 3;
                // popUpIndex = 8;  //3 star pass
            }


            if (currentStarsNum > PlayerPrefs.GetInt("Lv" + levelIndex))
            {
                PlayerPrefs.SetInt("Lv" + levelIndex, currentStarsNum);
            }

            Debug.Log(PlayerPrefs.GetInt("Lv" + levelIndex, currentStarsNum));

            BackButton();

        }
        
    }
    

    



}