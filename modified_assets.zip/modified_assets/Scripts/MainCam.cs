using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainCam : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
      // continue BGM
      Music_Trans.instance.gameObject.GetComponent<AudioSource>().Play();
    }

}
