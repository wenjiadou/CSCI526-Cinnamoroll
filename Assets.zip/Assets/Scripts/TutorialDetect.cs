using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialDetect : MonoBehaviour
{
    public CapsuleCollider tutorialChangeTrigger1;
    public bool detect1 = false;
    public CapsuleCollider tutorialChangeTrigger2;
    public bool detect2 = false;

    private void OnTriggerEnter(Collider other)
    {
        // if player is inside destination trigger play victory clip
        if (other == tutorialChangeTrigger1)
        {
            detect1 = true;
        }

        if (other == tutorialChangeTrigger2)
        {
            detect2 = true;
        }
    }
}
