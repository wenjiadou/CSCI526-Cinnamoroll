using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class TimeLimit : MonoBehaviour
{
    public float timeLimit = 20f;
    public GameObject timeCounter;

    private HeartSystem heartSystem;

    void Start()
    {
        // timeCounter = GameObject.FindGameObjectWithTag("Count");
        heartSystem = gameObject.GetComponent<HeartSystem>();
    }

    // Update is called once per frame
    void Update()
    {
        timeLimit-=Time.deltaTime;
        if (timeLimit<=30.9) {
            if (timeCounter.activeSelf == false) timeCounter.SetActive(true);
            timeCounter.GetComponent<TMP_Text>().text = "Remaining time: " + ((int)timeLimit).ToString();
        }
        if (timeLimit<=0){
            // transform.gameObject.SetActive(false);
            heartSystem.dead = true;
            timeCounter.GetComponent<TMP_Text>().text = "Time out!";

        }
    }
}
